package com.elnaranjo.pibi2goserver.Common;

import com.elnaranjo.pibi2goserver.Model.User;

public class Common {
    public static User currentUser;

    public static final String UPDATE = "Actualizar";
    public static final String DELETE = "Borrar";
    public static final int PICK_IMAGE_REQUEST = 71;

}
